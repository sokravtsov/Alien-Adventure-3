//
//  ShuffleStrings.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 9/30/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func shuffleStrings(s1 s1: String, s2: String, shuffle: String) -> Bool {
        if s1.isEmpty && s2.isEmpty && shuffle.isEmpty {
            return true
        }
        var s1Shuffle = String()
        var s2Shuffle = String()
        if shuffle.characters.count != s1.characters.count + s2.characters.count {
            return false
        } else {
            for char in shuffle.characters {
                if s1.containsString(String(char)) {
                    s1Shuffle.append(char)
                }
                if s2.containsString(String(char)) {
                    s2Shuffle.append(char)
                }
            }
            if s1Shuffle == s1 && s2Shuffle == s2 {
                return true
            } else {
                return false
            }
        }
    }
}
